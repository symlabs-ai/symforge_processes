# ForgeProcess — Roteiro Operacional & Estado de Execução

> Documento de referência para **symbiotas** e humanos seguirem o fluxo
> completo do ForgeProcess (MDD → BDD → Execution → Delivery → Feedback),
> com **checklists por etapa** e **arquivos obrigatórios**.
>
> Objetivo: evitar “atalhos” (ex.: pular Roadmap Planning e ir direto para TDD)
> e manter um ponto único de verdade sobre o estado atual da execução.
>
> **Regra operacional para symbiotas:** no início de **cada fase** (MDD, BDD,
> Execution, Delivery, Feedback), o symbiota responsável por aquela fase deve
> ser carregado/ativado para conduzir a execução junto ao usuário, atuando como
> facilitador e executor das tarefas daquela fase. A cada etapa concluída,
> esse symbiota (ou o orquestrador que o invocou) deve **atualizar o progresso**
> neste arquivo (`process/process_execution_state.md`), marcando os checkboxes
> relevantes e ajustando `current_phase`, `last_completed_step` e
> `next_recommended_step`.

---

## 0. Convenções gerais

- Sempre seguir a ordem macro (não inverter):
  - Intenção de valor → **MDD** → **BDD** → **Execution (Roadmap → TDD)** → **Delivery (Sprint + Review)** → **Feedback**.
- Arquitetura e backlog **NUNCA** são definidos dentro do TDD:
  - TDD implementa o que já está definido em `specs/roadmap/` (principalmente `BACKLOG.md`).
  - Roadmap Planning é o lugar para validar arquitetura, dependências e priorização.
- Persistência:
  - Artefatos em Markdown/YAML, versionados em Git.
  - Commits preferencialmente por etapa/fase, com mensagem clara.
- Symbiotas relevantes:
  - `mdd_coach`, `mdd_publisher`
  - `bdd_coach`
  - `roadmap_coach`, `execution_coach`, `mark_arc`
  - `tdd_coder`, `forge_coder`
  - `sprint_coach`, `delivery_coach`
  - `bill_review`, `jorge_the_forge`

---

## 1. Estado atual do ForgeProcess (preencher e manter)

> Campo de **estado vivo** para ser atualizado pelos agentes/symbiotas.
> Pode ser usado pelo orquestrador para saber onde o projeto está.

- [ ] `current_phase`: `mdd` | `bdd` | `execution.roadmap_planning` | `execution.tdd` | `delivery.sprint` | `delivery.review` | `feedback`
- [ ] `current_cycle`: identificador do ciclo atual (ex.: `cycle-01`).
- [ ] `current_sprint`: se aplicável, ex.: `sprint-01`.
- [ ] `last_completed_step`: id da última etapa concluída (ex.: `mdd.etapa_03_pitch`).
- [ ] `next_recommended_step`: id da próxima etapa (ex.: `execution.roadmap_planning.etapa_00_validacao_stakeholder`).

> Convenção sugerida: atualizar este bloco ao final de cada etapa significativa
> (pelo menos por fase) para facilitar handoffs entre agentes.

---

## 2. Bootstrap do projeto

- [ ] Verificar estrutura mínima:
  - [ ] Diretórios: `process/`, `specs/`, `project/`, `src/`, `tests/`
  - [ ] Arquivos: `process/PROCESS.yml`, `process/README.md`
- [ ] Criar hipótese inicial (se não existir):
  - [ ] `docs/hipotese.md` (template: `process/mdd/templates/template_hipotese.md`)
- [ ] Atualizar estado:
  - [ ] `current_phase = mdd`
  - [ ] `last_completed_step = null`
  - [ ] `next_recommended_step = mdd.etapa_01_concepcao`

---

## 3. Fase MDD — Market Driven Development

Referência: `process/mdd/PROCESS.yml`

> Symbiota responsável pela fase (etapas 3.1 a 3.6): `mdd_coach`.  
> Revisor de processo ao final da fase: `jorge_the_forge` (audita se o MDD seguiu o ForgeProcess).

### 3.1 Etapa 01 — Concepção da Visão

- Entradas:
  - [ ] `docs/hipotese.md`
- Saídas (criar/preencher):
  - [ ] `docs/visao.md` (template: `process/mdd/templates/template_visao.md`)
- Critério de conclusão:
  - [ ] Visão aprovada pelo stakeholder (decisão `validar_visao = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = mdd.etapa_01_concepcao`
    - [ ] `next_recommended_step = mdd.etapa_02_sintese`

### 3.2 Etapa 02 — Síntese Executiva

- Entradas:
  - [ ] `docs/visao.md`
- Saídas:
  - [ ] `docs/sumario_executivo.md` (template: `process/mdd/templates/template_sumario_executivo.md`)
  - [ ] (opcional) `output/docs/sumario_executivo.pdf` — gerado por `mdd_publisher`
- Critério de conclusão:
  - [ ] Síntese aprovada (`validar_sintese = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = mdd.etapa_02_sintese`
    - [ ] `next_recommended_step = mdd.etapa_03_pitch`

### 3.3 Etapa 03 — Pitch de Valor

- Entradas:
  - [ ] `docs/visao.md`
  - [ ] `docs/sumario_executivo.md`
- Saídas:
  - [ ] `docs/pitch_deck.md` (template: `process/mdd/templates/template_pitch_deck.md`)
  - [ ] (opcional) `output/docs/pitch_deck.pptx` — gerado por `mdd_publisher`
- Critério de conclusão:
  - [ ] Pitch aprovado (`validar_pitch = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = mdd.etapa_03_pitch`
    - [ ] `next_recommended_step = mdd.etapa_04_validacao`

### 3.4 Etapa 04 — Validação Pública Inicial

- Entradas:
  - [ ] `docs/visao.md`
  - [ ] `docs/sumario_executivo.md`
  - [ ] `docs/pitch_deck.md`
- Saídas:
  - [ ] `docs/sites/site_A.md` (template: `process/mdd/templates/template_site.md`)
  - [ ] `docs/sites/site_B.md` (template: `process/mdd/templates/template_site.md`)
  - [ ] `docs/sites/site_C.md` (template: `process/mdd/templates/template_site.md`)
  - [ ] (opcionais) `output/docs/sites/site_*.html` — por `mdd_publisher`
  - [ ] `docs/resultados_validacao.md` (template: `process/mdd/templates/template_resultados_validacao.md`)
  - [ ] (opcional) `output/docs/resultados_validacao.html`
- Critério de conclusão:
  - [ ] Stakeholder confirma que dados de validação estão prontos (`validar_landing_pages = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = mdd.etapa_04_validacao`
    - [ ] `next_recommended_step = mdd.etapa_05_avaliacao`

### 3.5 Etapa 05 — Avaliação Estratégica

- Entradas:
  - [ ] `docs/resultados_validacao.md`
- Saídas (uma ou mais, dependendo da decisão):
  - [ ] `docs/aprovacao_mvp.md` (template: `process/mdd/templates/template_aprovacao_mvp.md`)
  - [ ] `docs/revisao_estrategica.md` (template: `process/mdd/templates/template_revisao_estrategica.md`)
  - [ ] `docs/rejeicao_projeto.md` (template: `process/mdd/templates/template_rejeicao_projeto.md`)
- Critério de conclusão:
  - [ ] Decisão do stakeholder (`decisao_mvp` = `approved` | `needs_revision` | `rejected`)
  - Se `needs_revision`: voltar para Etapa 01 e atualizar estado.
  - Se `rejected`: macro-processo termina (`end_projeto_rejeitado`).
  - Se `approved`:
    - [ ] `next_recommended_step = mdd.etapa_06_handoff`

### 3.6 Etapa 06 — Handoff para BDD

- Entradas:
  - [ ] `docs/aprovacao_mvp.md`
- Saídas:
  - [ ] `docs/handoff_bdd.md` (template: `process/mdd/templates/template_handoff_bdd.md`)
- Critério de conclusão:
  - [ ] Handoff concluído (`return_approved`)
  - Atualizar estado:
    - [ ] `current_phase = bdd`
    - [ ] `last_completed_step = mdd.etapa_06_handoff`
    - [ ] `next_recommended_step = bdd.etapa_01_mapeamento`

---

## 4. Fase BDD — Behavior Driven Development

Referência: `process/bdd/PROCESS.yml`

> Symbiota responsável pela fase (etapas 4.1 a 4.6): `bdd_coach`.  
> Revisor de processo ao final da fase: `jorge_the_forge` (audita se o BDD seguiu o ForgeProcess).

### 4.1 Etapa 01 — Mapeamento de Comportamentos

- Entradas:
  - [ ] `docs/visao.md`
  - [ ] `docs/aprovacao_mvp.md`
- Saídas:
  - [ ] `specs/bdd/drafts/behavior_mapping.md`
- Critério de conclusão:
  - [ ] Mapeamento aprovado (`validar_mapeamento = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = bdd.etapa_01_mapeamento`
    - [ ] `next_recommended_step = bdd.etapa_02_features`

### 4.2 Etapa 02 — Escrita de Features Gherkin

- Entradas:
  - [ ] `specs/bdd/drafts/behavior_mapping.md`
- Saídas:
  - [ ] `specs/bdd/**/*.feature` (cenários Given/When/Then, linguagem de negócio)
- Critério de conclusão:
  - [ ] Features aprovadas (`validar_features = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = bdd.etapa_02_features`
    - [ ] `next_recommended_step = bdd.etapa_03_organizacao`

### 4.3 Etapa 03 — Organização e Tagging

- Entradas:
  - [ ] `specs/bdd/**/*.feature`
- Saídas:
  - [ ] Estrutura de pastas organizada (10_, 20_, 30_, etc.) em `specs/bdd/`
  - [ ] Tags aplicadas (@ci-fast, @ci-int, @e2e) em todas as features
  - [ ] `specs/bdd/README.md` atualizado
- Critério de conclusão:
  - [ ] Organização e tags aprovadas (`validar_organizacao = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = bdd.etapa_03_organizacao`
    - [ ] `next_recommended_step = bdd.etapa_04_tracks`

### 4.4 Etapa 04 — Criação de tracks.yml

- Entradas:
  - [ ] `specs/bdd/**/*.feature`
  - [ ] `docs/visao.md`
- Saídas:
  - [ ] `specs/bdd/tracks.yml`
- Critério de conclusão:
  - [ ] tracks.yml aprovado (`validar_tracks = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = bdd.etapa_04_tracks`
    - [ ] `next_recommended_step = bdd.etapa_05_skeleton`

### 4.5 Etapa 05 — Skeleton de Automação

- Entradas:
  - [ ] `specs/bdd/**/*.feature`
- Saídas:
  - [ ] `tests/bdd/test_*_steps.py`
  - [ ] `tests/bdd/conftest.py`
  - [ ] `pytest.ini`
- Critério de conclusão:
  - [ ] Skeleton aprovado (`validar_skeleton = approved`)
  - Atualizar estado:
    - [ ] `last_completed_step = bdd.etapa_05_skeleton`
    - [ ] `next_recommended_step = bdd.etapa_06_handoff`

### 4.6 Etapa 06 — Handoff para Roadmap Planning

- Entradas:
  - [ ] `specs/bdd/**/*.feature`
  - [ ] `specs/bdd/tracks.yml`
  - [ ] `tests/bdd/`
- Saídas:
  - [ ] `specs/bdd/HANDOFF_BDD.md`
- Critério de conclusão:
  - [ ] Tech lead confirma completude (`decisao_completude = complete`)
  - Atualizar estado:
    - [ ] `current_phase = execution.roadmap_planning`
    - [ ] `last_completed_step = bdd.etapa_06_handoff`
    - [ ] `next_recommended_step = execution.roadmap_planning.etapa_00_validacao_stakeholder`

---

## 5. Fase Execution — Roadmap Planning + TDD

Referência: `process/execution/PROCESS.yml`

### IMPORTANTE — Ordem obrigatória dentro de Execution

- [ ] **NUNCA** chamar `tdd_coder` direto logo após BDD.
- [ ] Sempre seguir:
  - [ ] `execution.roadmap_planning` → gerar `specs/roadmap/*`
  - [ ] **só depois** `execution.tdd` (TDD Workflow)
- TDD só começa se:
  - [ ] `specs/roadmap/ROADMAP.md` existir
  - [ ] `specs/roadmap/BACKLOG.md` existir

### 5.1 Roadmap Planning (execution.roadmap_planning)

Referência: `process/execution/roadmap_planning/PROCESS.yml`

> Symbiotas por intervalo de etapas desta fase:
> - Etapas 5.1.1–5.1.2 (validação arquitetural + stack/ADRs): `mark_arc` (análise arquitetural ForgeBase).
> - Etapas 5.1.3–5.1.6 (dependências, quebra, estimativa, backlog): `roadmap_coach`.

#### 5.1.1 Etapa 00 — Validação Arquitetural com Stakeholders

- Entradas:
  - [ ] `docs/visao.md`
  - [ ] `specs/bdd/*.feature`
  - [ ] `specs/bdd/tracks.yml`
- Saídas:
  - [ ] `specs/roadmap/ARCHITECTURAL_QUESTIONNAIRE.md`
  - [ ] `specs/roadmap/ARCHITECTURAL_DECISIONS_APPROVED.md`
- Critério de conclusão:
  - [ ] Stakeholder aprova propostas (`decisao_aprovacao_arquitetura = approved`)

#### 5.1.2 Etapa 01 — Definição Arquitetural e Stack (ADR)

- Entradas:
  - [ ] `specs/roadmap/ARCHITECTURAL_DECISIONS_APPROVED.md`
- Saídas:
  - [ ] `specs/roadmap/TECH_STACK.md`
  - [ ] `specs/roadmap/ADR.md`
  - [ ] `specs/roadmap/adr/*.md`
  - [ ] `specs/roadmap/HLD.md`
  - [ ] `specs/roadmap/LLD.md`

#### 5.1.3 Etapa 02 — Análise de Dependências

- Entradas:
  - [ ] `specs/bdd/tracks.yml`
  - [ ] `specs/bdd/**/*.feature`
- Saídas:
  - [ ] `specs/roadmap/dependency_graph.md`

#### 5.1.4 Etapa 03 — Quebra de Features

- Entradas:
  - [ ] `specs/bdd/**/*.feature`
  - [ ] `specs/roadmap/dependency_graph.md`
- Saídas:
  - [ ] `specs/roadmap/feature_breakdown.md`

#### 5.1.5 Etapa 04 — Estimativa e Priorização

- Entradas:
  - [ ] `specs/roadmap/feature_breakdown.md`
  - [ ] `specs/roadmap/dependency_graph.md`
- Saídas:
  - [ ] `specs/roadmap/estimates.yml`

#### 5.1.6 Etapa 05 — Criação do Roadmap e Backlog

- Entradas:
  - [ ] `specs/roadmap/estimates.yml`
  - [ ] `specs/roadmap/dependency_graph.md`
- Saídas:
  - [ ] `specs/roadmap/ROADMAP.md`
  - [ ] `specs/roadmap/BACKLOG.md`
- Critério de conclusão:
  - [ ] Tech lead aprova roadmap (`decisao_aprovacao_roadmap = approved`)
  - Atualizar estado:
    - [ ] `current_phase = execution.tdd`
    - [ ] `last_completed_step = execution.roadmap_planning.etapa_05_roadmap_backlog`
    - [ ] `next_recommended_step = execution.tdd.phase_1_selecao`

### 5.2 TDD Workflow (execution.tdd)

Referência: `process/execution/tdd/PROCESS.yml`

> Symbiota responsável pelas etapas 5.2.1–5.2.5: `tdd_coder` (executa TDD Red-Green-Refactor em cima da arquitetura definida no Roadmap Planning).  
> Regra: **TDD SEMPRE parte de um item do `BACKLOG.md`.**

#### 5.2.1 Phase 1 — Seleção da Tarefa e BDD Scenarios

- Entradas:
  - [ ] `specs/roadmap/BACKLOG.md`
  - [ ] `specs/bdd/**/*.feature`
- Saídas:
  - [ ] `tests/bdd/test_*_steps.py` (arquivo de teste preparado/focado na tarefa)

#### 5.2.2 Phase 2 — Test Setup (RED)

- Entradas:
  - [ ] `specs/bdd/**/*.feature`
- Saídas:
  - [ ] `tests/bdd/test_*.py` com teste falhando (RED)

#### 5.2.3 Phase 3 — Minimal Implementation (GREEN)

- Entradas:
  - [ ] `tests/bdd/test_*.py`
- Saídas:
  - [ ] `src/**/*.py` (código mínimo para passar o teste)

#### 5.2.4 Phase 4 — Refactor

- Entradas:
  - [ ] `src/**/*.py`
- Saídas:
  - [ ] `src/**/*.py` refatorado, testes ainda verdes

#### 5.2.5 Phase 5 — Commit e Próxima Tarefa

- Entradas:
  - [ ] `src/**/*.py`
  - [ ] `tests/**/*.py`
- Saídas:
  - [ ] `specs/roadmap/BACKLOG.md` atualizado (tarefa marcada como concluída)
- Critérios de laço:
  - [ ] Se `backlog.has_pending_tasks()` → voltar à Phase 1 (próxima tarefa).
  - [ ] Se não há tarefas → decidir se precisa `needs_roadmap_revision`.
- Ao final do TDD para o ciclo:
  - [ ] `return_complete` → Execution conclui e chama Delivery.
  - Atualizar estado:
    - [ ] `current_phase = delivery.sprint`
    - [ ] `last_completed_step = execution.tdd.phase_5_commit` (última tarefa do ciclo)
    - [ ] `next_recommended_step = delivery.sprint.sprint_planning`

> Revisor de processo ao final da fase 5 (Execution): `jorge_the_forge` (audita se Roadmap Planning + TDD seguiram o ForgeProcess, incluindo relação com BDD e backlog).

---

## 6. Fase Delivery — Sprint + Review

Referência: `process/delivery/PROCESS.yml`

### 6.1 Sprint (delivery.sprint)

Referência: `process/delivery/sprint/PROCESS.yml`

> Symbiota responsável por facilitar a fase (etapas 6.1.1–6.1.5): `sprint_coach`.  
> Symbiota executor de código nas etapas de implementação/commit (6.1.3 e 6.1.5): `forge_coder`.

#### 6.1.1 Sprint Planning

- Entradas:
  - [ ] `specs/roadmap/BACKLOG.md`
- Saídas:
  - [ ] `project/sprints/sprint-N/planning.md`

#### 6.1.2 Session Mini-Planning

- Entradas:
  - [ ] `project/sprints/sprint-N/planning.md`
- Saídas:
  - [ ] `project/sprints/sprint-N/sessions/session-M.md`

#### 6.1.3 Session Implementation

> Symbiota executor de código na sessão: `forge_coder` (implementa features usando TDD, seguindo arquitetura ForgeBase).

- Entradas:
  - [ ] `project/sprints/sprint-N/sessions/session-M.md`
- Saídas:
  - [ ] `src/**/*.py`
  - [ ] `tests/**/*.py`

#### 6.1.4 Session Review

- Entradas:
  - [ ] `src/**/*.py`
  - [ ] `tests/**/*.py`
- Saídas:
  - [ ] `project/sprints/sprint-N/sessions/session-M.md` atualizado com resultado

#### 6.1.5 Session Commit

- Saídas:
  - [ ] `project/sprints/sprint-N/progress.md`
- Critério:
  - [ ] Se `sprint.has_remaining_sessions()` → repetir mini-planning/implementation/review/commit.
  - [ ] Senão → `session_complete` e Delivery chama Review.

### 6.2 Review (delivery.review)

Referência: `process/delivery/review/PROCESS.yml`

#### 6.2.1 Day 1 — bill-review (Technical)

- Entradas:
  - [ ] `src/**/*.py`
  - [ ] `tests/**/*.py`
  - [ ] `specs/bdd/**/*.feature`
- Saídas:
  - [ ] `project/sprints/sprint-N/review.md`

#### 6.2.2 Day 2 — Jorge the Forge (Process)

- Entradas:
  - [ ] `project/sprints/sprint-N/review.md`
  - [ ] `project/sprints/sprint-N/planning.md`
  - [ ] `project/sprints/sprint-N/progress.md`
- Saídas:
  - [ ] `project/sprints/sprint-N/jorge-process-review.md`

#### 6.2.3 Day 3 — Stakeholder Review & Deploy

- Entradas:
  - [ ] `project/sprints/sprint-N/review.md`
  - [ ] `project/sprints/sprint-N/jorge-process-review.md`
- Saídas:
  - [ ] `project/sprints/sprint-N/stakeholder-approval.md`
- Decisão:
  - [ ] Se `approved` e `!backlog.has_pending_items()` → `deployed`.
  - [ ] Se `needs_fixes` → volta a Sprint.
  - [ ] Se `needs_revision`/`rollback` → Execution precisa revisar (típico).
- Atualizar estado:
  - [ ] `current_phase = feedback` (quando `return_deployed`)
  - [ ] `last_completed_step = delivery.review.stakeholder_review`
  - [ ] `next_recommended_step = feedback.feedback_collect`

> Revisores ao final da fase 6 (Delivery):  
> - `bill_review` — revisão técnica da sprint e do incremento entregue;  
> - `jorge_the_forge` — revisão de processo da sprint (compliance com ForgeProcess).

---

## 7. Fase Feedback — Reflexão e Próximos Ciclos

Referência: macro em `process/PROCESS.yml` (phases.feedback)

### 7.1 Coletar Feedback

- Entradas (exemplos):
  - [ ] Métricas operacionais (logs, observabilidade)
  - [ ] KPIs de valor definidos na visão / tracks
- Saídas:
  - [ ] Registro de métricas e observações (sugestão: `project/docs/feedback/cycle-N.md`)

### 7.2 Analisar Feedback

- Atividades:
  - [ ] Analisar dados, comparar com KPIs
  - [ ] Sugerir ajustes de visão, novos ValueTracks ou encerrar ciclo

### 7.3 Decisões de ciclo

- [ ] Decisão 1 — Visão precisa mudar?
  - [ ] Se **sim**:
    - [ ] `current_phase = mdd`
    - [ ] `next_recommended_step = mdd.etapa_01_concepcao`
  - [ ] Se **não**:
    - [ ] Decisão 2 — Há mais ValueTracks a implementar?
      - [ ] Se “continuar”:
        - [ ] `current_phase = bdd`
        - [ ] `next_recommended_step = bdd.etapa_01_mapeamento`
      - [ ] Se “completo”:
        - [ ] `end_ciclo_completo`

> Revisão e registro de aprendizados ao final da fase 7 (Feedback):  
> - `jorge_the_forge` é responsável por consolidar aprendizados de processo e atualizar artefatos de feedback;  
> - `bill_review` pode ser invocado para revisar implicações técnicas identificadas no feedback, mas o registro formal de aprendizados é conduzido por Jorge.

---

## 8. Regras específicas para symbiotas (resumo rápido)

- `tdd_coder`:
  - [ ] Nunca iniciar implementação se `specs/roadmap/BACKLOG.md` não existir.
  - [ ] Em caso de ausência, registrar no contexto: “É necessário rodar Roadmap Planning antes do TDD” e solicitar intervenção de `roadmap_coach`.
- `forge_coder`:
  - [ ] Implementar e commitar código principalmente durante a fase de Delivery (sprints), seguindo TDD e a arquitetura definida em Execution.
  - [ ] Trabalhar sempre em cima de itens do backlog definidos e aprovados; não inventar escopo novo durante a sprint.
- `roadmap_coach`:
  - [ ] Sempre produzir pelo menos: `TECH_STACK.md`, `HLD.md`, `LLD.md`, `ROADMAP.md`, `BACKLOG.md`.
- `execution_coach`:
  - [ ] Garantir que o fluxo BDD → Roadmap Planning → TDD seja respeitado, sem pular etapas.
  - [ ] Manter `current_phase` e `next_recommended_step` coerentes ao transitar entre `execution.roadmap_planning`, `execution.tdd` e `delivery.sprint`.
- `mark_arc`:
  - [ ] Conduzir a análise arquitetural nas etapas 00 e 01 de Roadmap Planning, alinhando decisões à arquitetura ForgeBase.
  - [ ] Apoiar a criação de TECH_STACK, ADRs, HLD e LLD coerentes com as regras do ForgeBase.
- `bdd_coach`:
  - [ ] Garantir que **todo ValueTrack** relevante do MDD está coberto por features e mapeado em `tracks.yml`.
- `sprint_coach`:
  - [ ] Facilitar Sprint Planning e Session Mini-Planning, mantendo `planning.md`, `sessions/*.md` e `progress.md` atualizados.
  - [ ] Coordenar o trabalho do `forge_coder` dentro de cada sessão de sprint.
- `delivery_coach`:
  - [ ] Coordenar a fase de Delivery como um todo, garantindo que sprint e review sigam o processo descrito em `process/delivery/`.
  - [ ] Orquestrar a execução de `bill_review` e `jorge_the_forge` no final de cada sprint.
- `bill_review` e `jorge_the_forge`:
  - [ ] Usar este arquivo como referência de “fluxo ideal” ao avaliar compliance.

Este arquivo deve ser atualizado incrementalmente durante a execução
para refletir o estado real do projeto e servir de **roteiro único**
para agentes humanos e symbiotas.
